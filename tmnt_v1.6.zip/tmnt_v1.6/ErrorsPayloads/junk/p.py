import re
import string
_mutatePayloadFile = "junkerror.txt"
_mutatePayloadFileObj = open(_mutatePayloadFile,"r")
_mutatePayloadFile1 = "clean.txt"
_mutatePayloadFileObj1 = open(_mutatePayloadFile,"w")
_payloadList = _mutatePayloadFileObj.readlines()
for _payloadline in _payloadList:
print (str(_payloadline))
_mutatePayloadFileObj.close()
_mutatePayloadFileObj1.close()
