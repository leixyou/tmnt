#! /usr/bin/env python 
# For Windows do a set path=%path%;C:\python27 to run properly (if not already done)

__version__ = "1.7"
__author__ = "Gerasimos Kassaras e-mail:g.kassaras@gmail.com"
__copyright__ = "Copyright(C) 2012 Gerasimos Kassaras (also known as lamehacker or rekcahemal Free Industries)"
__license__ = "GNU GPL v2"

# -*- coding: iso-8859-15 -*-

# Importing libraries
import urllib
import base64
import os
import re
import time
import sys

# ------------------------------------ Paths -----------------------------------------------------------

CD = os.getcwd()

CharPath = CD + "/CharContainer/"

# ------------------------------------ CharContainer ----------------------------------------------------

genericFuzzingCharSet = CharPath +"GenericCharacterFuzzing.lst"
postfixFile = CharPath +"postfix_Container.lst"
fillerFile = CharPath +"space_Filler_Container.lst"
suffixFile = CharPath +"suffix_Container.lst"
sqlKeywordFile = CharPath + "sql_Keyword_Container.lst"

global tsleep 

tsleep = 5

def printBanner():
   
 print(' I am handsome turtle...')
 print('                                       ___-------___')
 print('                                   _-~~             ~~-_')
 print('                               _-~                    /~-_')
 print('             /^\__/^\         /~  \                   /    \'')
 print('           /|  O|| O|        /      \_______________/        \'')
 print('          | |___||__|      /       /                \          \'')
 print('          |          \    /      /                    \          \'')
 print('          |   (_______) /______/                        \_________ \'')
 print('          |         / /         \                      /            \'')
 print('           \         \^\\         \                  /               \     /')
 print('             \         ||           \______________/      _-_       //\__//')
 print('               \       ||------_-~~-_ ------------- \ --/~   ~\    || __/')
 print('                 ~-----||====/~     |==================|       |/~~~~~')
 print('                  (_(__/  ./     /                    \_\      \.')
 print('                         (_(___/                         \_____)_)')
 print("------------------------------------------------------------------------------\n")
 print(" Author: rekcahemal Free Industries")
 print(" Feedback/Bugs : g.kassaras@gmail.com")
 print(" Blog : http://blog.elusivethoughts.org")
 print(" Twitter: @lamehacker")
 print("------------------------------------------------------------------------------\n")

#########################################################################################################
##                                      Exit functions
#########################################################################################################

def exitScript():
 
    print("Bye bye...")

    sys.exit(0)
      
#########################################################################################################
##                                      Check functions
#########################################################################################################

def checkFileExitstance(_filename) :
    
 try:

    open(_filename)

    return True

 except:

    printFileDoesNotExist()

    return False

#----------------------------------------------------------------------------------------

def checkDirectoryExitstance() :
 
 if (os.path.isdir(CharPath)):

    return True

 else:

    printDirectoryDoesNotExist()

    return False

#########################################################################################################
##                                      Print functions
#########################################################################################################

def printEnter():

    print("\n")

#----------------------------------------------------------------------------------------

def printCleanUpMessage():

    print("Database has been cleaned up...\n")

#----------------------------------------------------------------------------------------

def printFileDoesNotExist():

    print("File does not exist please try gain...\n")

#----------------------------------------------------------------------------------------

def printDirectoryDoesNotExist():

    print("Directory CharContainer does not exist or you are in the wrong directory path\n")

#----------------------------------------------------------------------------------------

def printUsageMessage():

    print("Usage: Type a single option then press enter type filename press enter again for help type help for the turtle type ban!")

#----------------------------------------------------------------------------------------

def printErrorMessage():
    
    print("Invalid argumantes were provided, please try again....\n")

#----------------------------------------------------------------------------------------
 
def printVersion():
    
    print ("::::::: Teenage Mutant Turtles version is 1.7 :::::::")

#----------------------------------------------------------------------------------------

def printFinishMessage():
    
    time.sleep(tsleep)

    print("Payload mutation is finished enjoy...")

#----------------------------------------------------------------------------------------

def printGeneratePayloadMessage():
    
    time.sleep(tsleep)

    print("Payload is being generated please wait...\n")

#----------------------------------------------------------------------------------------

def printCollectedPayloadMessage():
    
    time.sleep(tsleep)

    print("Payload collected...\n")

#----------------------------------------------------------------------------------------
 
def printHelpMessage():
    
    print("help           :  Print help message for providing proper script arguments\n")    
    print("sfx            :  This option can be used for mutating SQL injection attack strings by adding suffixes to the payloads such as EXEC, %00 e.t.c\n") 
    print("pfx            :  This option can be used for mutating SQL injection attack strings by adding postfixes to the payloads e.g. --, );-- e.t.c\n")
    print("url            :  This option can be used for mutating SQL injection attack strings by url encoding the payloads\n")
    print("flr            :  This option can be used for mutating SQL injection attack strings by filling the gaps with SQL commends, url encoded space and other special characters\n")
    print("b64            :  This option can be used for mutating attack strings by base 64 encoding the payloads\n")
    print("hex            :  This option can be used for mutating attack strings by hex encoding the payload\n")
    print("ban            :  Print ThE script banner\n")
    print("ver            :  Print version of the script\n")
    print("all            :  Perform all mutations to the file provided as an input\n")
    print("ded            :  Deduplicate all attack strings payloads to the file provided as an input\n")
    print("XXSMe          :  Converts the payload given as an input to an xml file that XXSMe can import\n")
    print("SQLInjectMe    :  Converts the payload given as an input to an xml file that SQLInjectMe can import\n")
    print("var            :  This option can be used for mutating SQL injection attack strings by adding case variation to the payloads\n")
    print("clean          :  Clean payload the whole database from trailing,leading spaces,blank lines and double payloads\n")
    print("allxss         :  Collect all xss payloads from the database into a single file\n")
    print("allmssql       :  Collect all mssql payloads from the database into a single file\n")
    print("allaccess      :  Collect all access payloads from the database into a single file\n")
    print("allpostgre     :  Collect all postgre payloads from the database into a single file\n")
    print("alloracle      :  Collect all oracle payloads from the database into a single file\n")
    print("allldap        :  Collect all ladap payloads from the database into a single file\n")
    print("allxxe         :  Collect all external entity payloads from the database into a single file\n")
    print("allssi         :  Collect all server side include payloads from the database into a single file\n")
    print("allcmd         :  Collect all os command payloads from the database into a single file\n")
    print("alluseragent   :  Collect all useragent payloads from the database into a single file\n")
    print("allpaths       :  Collect all path traversal payloads from the database into a single file\n")
    print("allxpath       :  Collect all XPath payloads from the database into a single file\n")
    print("allxml         :  Collect all xml payloads from the database into a single file\n")
    print("allerrors      :  Collect all error payloads from the database into a single file\n")
    print("allhttpmethods :  Collect all http method payloads from the database into a single file\n")

#########################################################################################################
##                                      Time functions
#########################################################################################################

def getTime():

    return time.strftime("%a%d%b%H_%M_%S", time.gmtime())

#----------------------------------------------------------------------------------------

def addDelay():
    
    time.sleep(tsleep)

    print(".")

#########################################################################################################
#-------------------------------- Database management --------------------------------------------------#
######################################################################################################### 

def getPayloadList(): # Reads through the payload database and collects all filenames with their paths
    
 _payloadFileList = []

 for _dirname, _dirnames, _filenames in os.walk('.'):
    
  for _filename in _filenames: # Get a file list with all payload files

      _payloadFileList.append(os.path.join(_dirname, _filename))

  for _payloadFileLine in _payloadFileList: # Save my turtles from being modified 

    if re.match(r'./tmntv...\.py',_payloadFileLine) or re.match(r'Readme.rtf',_payloadFileLine) or re.match(r'.\\tmntv...\.py',_payloadFileLine) or re.match(r'.\\Readme.rtf',_payloadFileLine):

        _payloadFileList.remove(_payloadFileLine)

 return _payloadFileList

#----------------------------------------------------------------------------------------

def cleanBlankLinesAndSpaces(_payloadFileList): # Remove all leading and trailing spaces, along with empty lines from the database 

 _filenamesMappedToPayloads = {} # Create that dictionary is going to pair filenames with their payloads (in the form of a list)

 for _payloadFilename in _payloadFileList: # Populate dictionary by mapping filenames to their list payloads
        
    _tmpFileObj1 = open(_payloadFilename,'r')
    
    _filenamesMappedToPayloads[_payloadFilename] = _tmpFileObj1.readlines() 
    
    _tmpFileObj1.close()
    
 for _filename, _payloads in _filenamesMappedToPayloads.iteritems(): # Write each sanitized payload back to the files
    
    _tmpFileObj2 = open(_filename,"w")
    
    for _payloadLine in _payloads:
        
        _tmpFileObj2.write((_payloadLine.strip()).rstrip()+"\n") # Remove trailing and leading spaces
        
    _tmpFileObj2.close()

#----------------------------------------------------------------------------------------

def cleanDoublesFromDb(_payloadFileList): # Does the actual cleaning if the double payloads for the whole databse
    
 _filenamesMappedToPayloads = {} # Create a dictionary that is going to pair filenames with their payloads (in the form of a list)
 
 _compareList = []

 for _payloadFilename in _payloadFileList: # Populate dictionary by mapping filenames to their list payloads
        
    _tmpFileObj1 = open(_payloadFilename,'r')
    
    _filenamesMappedToPayloads[_payloadFilename] = _tmpFileObj1.readlines() 
    
    _tmpFileObj1.close()

 for _payloadFilename, _payloadFileList in _filenamesMappedToPayloads.iteritems(): # Write each sanitized payload back to the files
    
    _tmpFileObj2 = open(_payloadFilename,"w")
    
    for _payloadLine in _payloadFileList:
        
        if _payloadLine not in _compareList: # Deduplicate 
            
            _compareList.append(_payloadLine)
            
            _tmpFileObj2.write(_payloadLine) # Remove trailing and leading spaces
        
    _tmpFileObj2.close()   

#----------------------------------------------------------------------------------------

def cleandb(_payloadFileList): # Cleans trailing, leading spaces and double payloads
    
 cleanBlankLinesAndSpaces(_payloadFileList)

 cleanDoublesFromDb(_payloadFileList)

#----------------------------------------------------------------------------------------

def convertFileToList(_originalPayloadFileObj): # Converts the input payload file to a list

 return _originalPayloadFileObj.readlines()

#----------------------------------------------------------------------------------------

def deduplicate(_payloadList): # Deduplicate payloads from a single payload files
 
 currentTime = getTime()+'_'
 
 _mutatePayloadFile = currentTime+"deduplicatedPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")
 
 _deduplictedList = list(set(_payloadList))
 
 for line in _deduplictedList:

  _mutatePayloadFileObj.write(line)
  
 _mutatePayloadFileObj.close()

#----------------------------------------------------------------------------------------

def selected(_option): # Return the selected argument

 if isallxss.match(_option):
    
    return "XSS"

 if isallmssql.match(_option):

    return "MSSQL"

 if isallaccess.match(_option):

    return "Access"

 if isallpostgre.match(_option):

    return "Postgre"

 if isalloracle.match(_option):

    return "Oracle"

 if isallldap.match(_option):

    return "LDAP"

 if isallxxe.match(_option):

    return "XXE"

 if isallssi.match(_option):

    return "SSII"

 if isallcmd.match(_option):

    return "Command"

 if isalluseragent.match(_option):

    return "UserAgents"

 if isallpaths.match(_option):

    return "PathTraversal"

 if isallxml.match(_option):

    return "XML"

 if isallhttpmethods.match(_option):

    return "HttpProtocolMethods"

 if isallxpath.match(_option):

    return "XPath"

 if isallerror.match(_option):

    return "Errors"

#----------------------------------------------------------------------------------------

def collector(_option,_payloadFileList): # Collect all payloads of the same type 
    
 currentTime = getTime()+'_'
 
 _collectedPayloadFiles = currentTime+"collectedPayloads.lst"

 _collectedPayloadFilesObj = open(_collectedPayloadFiles,"a")

 for _payloadFile in _payloadFileList:
    
    _harvestFileObj = open(_payloadFile,"r")
    
    if re.search(selected(_option),_payloadFile):
        
        _collectedPayloadFilesObj.write(_harvestFileObj.read())

############################################################################################
#----------------------------------- Payload mutators -------------------------------------#
############################################################################################

def suffixAdder(_payloadList): # Adding suffixes
 
 checkDirectoryExitstance() 
 
 currentTime = getTime()+'_'
 
 _mutatePayloadFile = currentTime+"suffixedPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")

 _suffixElementsFile = suffixFile

 _suffixElementObj = open(_suffixElementsFile,"r")
    
 _suffixList = _suffixElementObj.readlines()
 
 for _suffix in _suffixList: 

  for _payloadline in _payloadList:

   _mutatePayloadFileObj.write(str(_suffix).rstrip()+str(_payloadline).rstrip()+"\n")

 _mutatePayloadFileObj.close()

#----------------------------------------------------------------------------------------

def postfixAdder(_payloadList): # Adding postfixes
    
 checkDirectoryExitstance() 

 currentTime = getTime()+'_'

 _mutatePayloadFile = currentTime = getTime()+'_'+"postfixedPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")

 _postfixElementsFile = postfixFile

 _postfixElementObj = open(_postfixElementsFile,"r")
    
 _postfixList = _postfixElementObj.readlines()
 
 for _postfix in _postfixList: 

  for _payloadline in _payloadList:

    _mutatePayloadFileObj.write(str(_payloadline).rstrip()+str(_postfix).rstrip()+"\n")
    
 _mutatePayloadFileObj.close()

#----------------------------------------------------------------------------------------

def replacer(_payloadList): # Filling the gaps 

 checkDirectoryExitstance() 

 currentTime = getTime()+'_'

 _mutatePayloadFile = currentTime+"spaceFilledPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")

 _space_FillerElementsFile = fillerFile

 _space_FillerElementObj = open(_space_FillerElementsFile,"r")
    
 _space_FillerList = _space_FillerElementObj.readlines()
 
 for _space_Filler in _space_FillerList: 

  for _payloadline in _payloadList:

   _mutatePayloadFileObj.write((str(_payloadline).rstrip()).replace(" ",(str(_space_Filler).rstrip()))+"\n")

 _mutatePayloadFileObj.close()

#----------------------------------------------------------------------------------------

def urlEncoder(_payloadList): # Do url encoding 

 currentTime = getTime()+'_'

 _mutatePayloadFile = currentTime = getTime()+'_'+"urlEncodedPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")
 
 for _payloadline in _payloadList:

  _mutatePayloadFileObj.write((urllib.urlencode({'q':str(_payloadline).rstrip()})).replace("q=", "")+"\n")

 _mutatePayloadFileObj.close()

#----------------------------------------------------------------------------------------

def base64Encoder(_payloadList): # Base 64 encoding

 currentTime = getTime()+'_'
 
 _mutatePayloadFile = currentTime+"base64EncodedPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")
 
 for _payloadline in _payloadList:

  _mutatePayloadFileObj.write(base64.b64encode(str(_payloadline).rstrip())+"\n")

 _mutatePayloadFileObj.close()

#----------------------------------------------------------------------------------------

def hexEncoder(_payloadList): # ASCII Hex encoding

 currentTime = getTime()+'_'

 _mutatePayloadFile =  currentTime = getTime()+'_'+"hexEncodedPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")
 
 for _payloadline in _payloadList:

  _mutatePayloadFileObj.write((str(_payloadline).rstrip()).encode("Hex")+"\n")

 _mutatePayloadFileObj.close()
 
#----------------------------------------------------------------------------------------

def XSSMeFormater(_payloadList): # XSSMe formats the input payload file

 currentTime = getTime()+'_'

 _mutatePayloadFile =  currentTime = getTime()+'_'+"XSSMeFormated.xml"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")
 
 _mutatePayloadFileObj.write("<exportedattacks><attacks><attack><attackString><![CDATA["+"\n")
 
 for _payloadline in _payloadList:
    
    _mutatePayloadFileObj.write((str(_payloadline).rstrip())+"\n"+"]]></attackString><signature>Script</signature></attack><attack><attackString><![CDATA["+"\n")
  
 _mutatePayloadFileObj.write("]]></attackString><signature>Script</signature></attack></attacks></exportedattacks>"+"\n")

 _mutatePayloadFileObj.close()
 
#----------------------------------------------------------------------------------------

def SQLInjectMeFormater(_payloadList):  # SQLInjectMe formats the input payload file

 currentTime = getTime()+'_'

 _mutatePayloadFile =  currentTime = getTime()+'_'+"SQLInjectMeFormated.xml"
 
 _mutatePayloadFileObj = open(_mutatePayloadFile,"w")

 _mutatePayloadFileObj.write("<exportedattacks><attacks><attack><attackString><![CDATA[")
 
 for _payloadline in _payloadList:
    
    _mutatePayloadFileObj.write((str(_payloadline).rstrip())+"]]></attackString><signature>TMNT</signature></attack><attack><![CDATA[")
  
 _mutatePayloadFileObj.write("</exportedattacks>")

 _mutatePayloadFileObj.close()
 
#----------------------------------------------------------------------------------------

def addCaseVarietionToKeyword(_sqlKeyword): # Adds case variation to a single keyword

 list1 = list(_sqlKeyword)

 for i in range(len(list1)):

  if i % 2 == 0:

   list1[i] = (list1[i].upper())

  else:

   list1[i] = (list1[i].lower())

 _sqlKeyword = ''.join(list1)

 return str(_sqlKeyword).rstrip()

#----------------------------------------------------------------------------------------

def searchPayloadLine(_keywordList, _payloadLine):
    # Search payload line with all SQL keywords contained in file CharContainer
    for _keyword in _keywordList:

        if re.search(_keyword.upper(),_payloadLine):

            return True

        if re.search(_keyword.lower(),_payloadLine):

            return True

    else:

        return False 

#----------------------------------------------------------------------------------------

def caseVarietionAdder(_payloadList): # Adding case variation
 
 checkDirectoryExitstance() 

 currentTime = getTime()+'_'

 _mutatePayloadFile = currentTime+"caseVarietionPayloads.lst"

 _mutatePayloadFileObj = open(_mutatePayloadFile,"a")
 
 _sqlKeywordElementsFile = sqlKeywordFile

 _sqlKeywordElementsFileObj = open(_sqlKeywordElementsFile,"r")

 _sqlKeywordList = _sqlKeywordElementsFileObj.readlines()
 
 _sqlKeyWordDictionary = {} # Holding SQL keywords mapping them to SQL keywords with case variation

 _searchList = [] # Holding only SQL keywords for later searching
 
 # Populate dictionary with SQL keywords and equvalent SQL keyword values with case variation
 for _sqlKeyword in _sqlKeywordList:

    _sqlKeyWordDictionary[str(_sqlKeyword).rstrip()] = addCaseVarietionToKeyword(_sqlKeyword)

 # Populate list with SQL keywords for searching later on
 for _sqlKeywordKey, _sqlKeywordValue in _sqlKeyWordDictionary.iteritems():

    _searchList.append(_sqlKeywordKey)

 for _payloadLine in  _payloadList:

    for _sqlKeywordKey, _sqlKeywordValue  in _sqlKeyWordDictionary.iteritems():

        if re.search(_sqlKeywordKey.upper(),_payloadLine):

            _payloadLine = str(_payloadLine).replace(_sqlKeywordKey.upper(),_sqlKeywordValue)

            # Search for all keywords within the payload line
            if not searchPayloadLine(_searchList,_payloadLine):
                _mutatePayloadFileObj.write(_payloadLine)
            
        if re.search(_sqlKeywordKey.lower(),_payloadLine):

            _payloadLine = str(_payloadLine).replace(_sqlKeywordKey.lower(),_sqlKeywordValue)

            # Search for all keywords within the payload line
            if not searchPayloadLine(_searchList,_payloadLine):

                _mutatePayloadFileObj.write(_payloadLine)

 _mutatePayloadFileObj.close()

#########################################################################################################
####################################### Argument handling...#############################################
#########################################################################################################

printUsageMessage()

option = raw_input("Enter option: ")

optionIsValid = re.compile("(hex)|(sfx)|(flr)|(url)|(pfx)|(b64)|(all)|(help)|(ban)|(ver)|(var)|(ded)|(clean)|(XSSMe)|(SQLInjectMe)|(allxss)|(allxxe)|(allxml)|(alloracle)|(allldap)|(allssi)|(allpaths)|(allxpath)|(allhttpmethods)|(alluseragent)|(allmssql)|(allcmd)|(allaccess)|(allpostgre)|(allerror)")

#------------------------------- Commands that have to do with the single file input ---------------------

isSuffix = re.compile("sfx")
isPostfix = re.compile("pfx")
isAll = re.compile("all")
isUrl = re.compile("url")
isVariation = re.compile("var")
isBase64 = re.compile("b64")
isFiller = re.compile("flr")
isHex = re.compile("hex")
isXSSMe = re.compile("XSSMe")
isSQLInjectMe = re.compile("SQLInjectMe")

#------------------------------- Commands that have to do with the tool ----------------------------------

ishelp = re.compile("help")
isBanner = re.compile("ban")
isVersion = re.compile("ver")

#------------------------------- Commands that have to do with db/payload cleanup ---------------------------------

isClean = re.compile("clean")
isDeduplicate = re.compile("ded")

#------------------------------- Commands that have to do with db payload collection ----------------------

isallxss = re.compile("allxss")
isallmssql = re.compile("allmssql")
isallaccess = re.compile("allaccess")
isallpostgre = re.compile("allpostgre")
isalloracle = re.compile("alloracle")
isallldap = re.compile("allldap")
isallxxe = re.compile("allxxe")
isallssi = re.compile("allssi")
isallcmd = re.compile("allcmd")
isalluseragent = re.compile("alluseragent")
isallpaths = re.compile("allpaths")
isallxpath = re.compile("allxpath")
isallxml = re.compile("allxml")
isallhttpmethods = re.compile("allhttpmethods")
isallerror = re.compile("allerror")

#------------------------------- Execute options that require a file as an input ----------------------------

if not (optionIsValid.match(option)):

   printErrorMessage()

   exitScript()
 
if  not not ishelp.match(option):

    printHelpMessage()

    exitScript()

if  not not isClean.match(option):

    cleandb(getPayloadList())

    printCleanUpMessage()

    exitScript()
    
if  not not isBanner.match(option):

    printBanner()

    exitScript()

if  not not isVersion.match(option):

    printVersion()

    exitScript()

if selected(option):
    
    collector(option,getPayloadList())

    printCollectedPayloadMessage()
    
    exitScript()

#----------------- Supply file input --------------------------------------------

filename = raw_input("Enter filename: ")

if not checkFileExitstance(filename) :

    exitScript()

#################################################################################
############################### Open payload file ###############################
#################################################################################

originalPayloadFileObj = open(filename,"r")

payloadList = convertFileToList(originalPayloadFileObj)

### Clean up ###  
originalPayloadFileObj.close()

#################################################################################
############################# Generating mutation file ##########################
#################################################################################

printGeneratePayloadMessage()

#---------------------------------------------------------------------------------

if  not not isAll.match(option):
    
    postfixAdder(payloadList)

    addDelay()

    suffixAdder(payloadList)

    addDelay()

    replacer(payloadList)

    addDelay()

    urlEncoder(payloadList)

    addDelay()

    base64Encoder(payloadList)

    addDelay()

    hexEncoder(payloadList)

    addDelay()

    caseVarietionAdder(payloadList)

    addDelay()

    SQLInjectMeFormater(payloadList)

    addDelay()

    XSSMeFormater(payloadList)

#---------------------------------------------------------------------------------

if  not not isSuffix.match(option):

    suffixAdder(payloadList)

if  not not isFiller.match(option):

    replacer(payloadList)

if  not not isPostfix.match(option):

    postfixAdder(payloadList)

if  not not isVariation.match(option):

    caseVarietionAdder(payloadList)

if  not not isHex.match(option):

    hexEncoder(payloadList)

if  not not isBase64.match(option):

    base64Encoder(payloadList)

if  not not isUrl.match(option):

    urlEncoder(payloadList)

if  not not isDeduplicate.match(option):

    deduplicate(payloadList)
    
if  not not isXSSMe.match(option):

    XSSMeFormater(payloadList)
    
if  not not isSQLInjectMe.match(option):

    SQLInjectMeFormater(payloadList)

printFinishMessage()

exitScript()
    
#---------------------------------------------------------------------------------

